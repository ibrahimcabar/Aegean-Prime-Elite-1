# Aegean Prime Elite — MVP v0.1

A Next.js 15 + TypeScript responsive global real estate marketplace **front-end prototype**.

## Run locally

1. Install Node.js 20 or newer.
2. In this directory, run `npm install`.
3. Run `npm run dev`.
4. Visit `http://localhost:3000`.

## Working in this prototype
- Responsive premium homepage and mobile navigation
- Demo property listings with local city/country/street filtering and property-type filtering
- Three example paid listing packages (display only)
- Open/close AI-style chat widget with explicit **demo-only** replies

## NOT implemented yet
- Live listing database, address autocomplete/geocoding or real map search
- Authentication, business verification, agency dashboard, listing upload
- Payment processing, recurring billing or commission contracts/tracking
- Real AI/API integration, multilingual translations, CRM or email notifications

All four listings and their images are **fictional preview content**; no properties are offered for sale through this prototype. Image URLs and Google Fonts require internet access. Prices are illustrative, not final.

## Suggested next milestones
1. Set up PostgreSQL with Prisma and a migration strategy.
2. Add role-based authentication: buyer, agent, developer, administrator.
3. Implement agency verification and moderation queues.
4. Build property CRUD, image storage, search indexing and geocoded addresses.
5. Integrate supported payments and invoice workflows by country.
6. Implement opt-in buyer leads, audit trail and legally reviewed commission agreements.
7. Connect AI assistant to approved listing search, with consent/privacy controls.

## Security
Never expose API keys in client code. Before production, implement validation, rate limiting, moderation, permissions, privacy policies and country-specific legal checks.
